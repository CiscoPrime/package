#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 5 ]]; then
  echo "Usage: $0 NODE_NAME NODE_IP INITIAL_CLUSTER CLUSTER_TOKEN DATA_DIR"
  echo "Example:"
  echo "  $0 etcd-1 10.140.10.169 'etcd-1=http://10.140.10.169:2380,etcd-2=http://10.140.11.161:2380,etcd-3=http://10.140.10.153:2380' cluster-1 /var/lib/etcd"
  exit 1
fi
NAME="$1"; IP="$2"; INITIAL_CLUSTER="$3"; TOKEN="$4"; DATA_DIR="$5"
# Binaries
sudo install -m 0755 -o root -g root ./etcd /usr/local/bin/etcd
sudo install -m 0755 -o root -g root ./etcdctl /usr/local/bin/etcdctl

# User + dirs
id -u etcd &>/dev/null || sudo useradd -r -s /usr/sbin/nologin -d /var/lib/etcd etcd
sudo install -d -o etcd -g etcd -m 0750 "$DATA_DIR"
sudo install -d -o root  -g root  -m 0755 /etc/etcd
sudo install -d -o etcd -g etcd -m 0750 /var/log/etcd
# Environment file
sudo tee /etc/etcd/etcd.env >/dev/null <<ENV
ETCD_NAME="${NAME}"
ETCD_DATA_DIR="${DATA_DIR}"
ETCD_INITIAL_CLUSTER="${INITIAL_CLUSTER}"
ETCD_INITIAL_CLUSTER_TOKEN="${TOKEN}"
ETCD_INITIAL_CLUSTER_STATE="new"

ETCD_LISTEN_PEER_URLS="http://${IP}:2380"
ETCD_LISTEN_CLIENT_URLS="http://${IP}:2379,http://127.0.0.1:2379"
ETCD_ADVERTISE_CLIENT_URLS="http://${IP}:2379"
ETCD_INITIAL_ADVERTISE_PEER_URLS="http://${IP}:2380"
ENV
sudo chown root:root /etc/etcd/etcd.env
sudo chmod 0644 /etc/etcd/etcd.env
sudo tee /etc/systemd/system/etcd.service >/dev/null <<'UNIT'
[Unit]
Description=etcd key-value store
Documentation=https://etcd.io/docs/
After=network-online.target
Wants=network-online.target

[Service]
EnvironmentFile=-/etc/etcd/etcd.env
User=etcd
Group=etcd
Type=notify
ExecStart=/usr/local/bin/etcd \
  --name=${ETCD_NAME} \
  --data-dir=${ETCD_DATA_DIR} \
  --listen-peer-urls=${ETCD_LISTEN_PEER_URLS} \
  --listen-client-urls=${ETCD_LISTEN_CLIENT_URLS} \
  --advertise-client-urls=${ETCD_ADVERTISE_CLIENT_URLS} \
  --initial-advertise-peer-urls=${ETCD_INITIAL_ADVERTISE_PEER_URLS} \
  --initial-cluster=${ETCD_INITIAL_CLUSTER} \
  --initial-cluster-token=${ETCD_INITIAL_CLUSTER_TOKEN} \
  --initial-cluster-state=${ETCD_INITIAL_CLUSTER_STATE}
Restart=always
RestartSec=2
LimitNOFILE=40000
[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now etcd
echo "Etcd installed. Check: sudo systemctl status etcd --no-pager"
