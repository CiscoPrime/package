from vizro.tables._dash_ag_grid import dash_ag_grid
from vizro.tables._dash_table import dash_data_table

__all__ = ["dash_ag_grid", "dash_data_table"]
